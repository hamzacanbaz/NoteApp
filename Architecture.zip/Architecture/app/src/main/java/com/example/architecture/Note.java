package com.example.architecture;

import androidx.room.Entity;
import androidx.room.PrimaryKey;

// db ismi note_table

@Entity(tableName = "note_table")
public class Note {

    // Bu isimlerde kolonlar olacak

    @PrimaryKey(autoGenerate = true)
    public int id;

    private String title;

    private String description;

    private int priority;

// Constructor

    public Note(String title, String description, int priority) {
        this.title = title;
        this.description = description;
        this.priority = priority;
    }


// Getter and Setter

    public void setId(int id) {
        this.id = id;
    }

    public int getId() {
        return id;
    }

    public String getTitle() {
        return title;
    }

    public String getDescription() {
        return description;
    }

    public int getPriority() {
        return priority;
    }
}
